# Líderes con Fe

Aplicación web para empresarios católicos con:

- Chat espiritual basado en Biblia Católica y Doctrina Social de la Iglesia.
- Respaldo local específico para consultas sobre ventas, empleados, salarios y despidos.
- Inspiración diaria con oración de mañana, consejo financiero y reflexión nocturna.
- Biblioteca Católica, Mayordomía y Gobernanza.
- Registro e inicio de sesión con Clerk.
- PostgreSQL con Drizzle ORM.

## Estructura

```text
artifacts/lideres-con-fe/   Frontend React + Vite
artifacts/api-server/       API Express
lib/api-spec/               Contrato OpenAPI
lib/api-client-react/       Cliente React generado
lib/api-zod/                Validaciones del servidor
lib/db/                     PostgreSQL + Drizzle
```

## Requisitos

- Node.js 20 o superior.
- pnpm 9 o superior.
- PostgreSQL 14 o superior.
- Una instancia de Clerk.
- Una clave de OpenAI para respuestas generativas.

## Instalación local

```bash
pnpm install
cp .env.example .env
```

Completa `.env` con:

- `DATABASE_URL`
- `OPENAI_API_KEY`
- `CLERK_SECRET_KEY`
- `CLERK_PUBLISHABLE_KEY`
- `VITE_CLERK_PUBLISHABLE_KEY`

Aplica el esquema de PostgreSQL:

```bash
pnpm run db:push
```

Comprueba los tipos:

```bash
pnpm run typecheck
```

## Desarrollo

En dos terminales:

```bash
pnpm --filter @workspace/api-server run dev
```

```bash
pnpm --filter @workspace/lideres-con-fe run dev
```

El frontend usa `/api` como ruta relativa. Para desarrollo separado, configura un proxy de Vite o sirve ambos procesos bajo el mismo dominio.

## Producción

Construye ambos servicios:

```bash
pnpm run build:api
pnpm run build:web
```

Inicia el API:

```bash
NODE_ENV=production PORT=8080 pnpm run start:api
```

El frontend compilado queda en:

```text
artifacts/lideres-con-fe/dist/public
```

Sirve esa carpeta como sitio estático y configura un proxy inverso para que:

```text
/api/*  ->  http://127.0.0.1:8080/api/*
```

Esto permite que las cookies de Clerk funcionen correctamente con el navegador. El frontend y el API deben estar bajo el mismo dominio o debes configurar explícitamente una estrategia de cookies/CORS para dominios distintos.

Ejemplo conceptual de Nginx:

```nginx
server {
    listen 80;
    server_name tu-dominio.com;

    root /ruta/al/proyecto/artifacts/lideres-con-fe/dist/public;
    index index.html;

    location /api/ {
        proxy_pass http://127.0.0.1:8080/api/;
        proxy_http_version 1.1;
        proxy_set_header Host $host;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
    }

    location / {
        try_files $uri $uri/ /index.html;
    }
}
```

## Clerk

En Clerk configura los dominios donde alojarás la aplicación y habilita el método de acceso que quieras usar. En el hosting externo:

- `VITE_CLERK_PUBLISHABLE_KEY` se expone al frontend y no es un secreto.
- `CLERK_SECRET_KEY` solo debe existir en el servidor API.
- `VITE_CLERK_PROXY_URL` normalmente debe quedar vacío fuera de Replit.

No pongas `CLERK_SECRET_KEY`, `OPENAI_API_KEY` ni `DATABASE_URL` en el código del frontend.

## Base de datos

El API exige `DATABASE_URL` al iniciar. La tabla `catholic_knowledge` contiene las fuentes católicas. Si la tabla está vacía, el API conserva fuentes locales de respaldo para que el chat siga respondiendo de forma útil.

## Comprobación

```bash
curl http://127.0.0.1:8080/api/healthz
```

Debe devolver:

```json
{"status":"ok"}
```

Las rutas `/api/chat` y `/api/inspiration/daily` requieren una sesión válida de Clerk.

## Nota sobre OpenAI

Si OpenAI devuelve `401` o `403`, el chat no queda vacío: utiliza el respaldo católico local. Para respuestas generativas, revisa que `OPENAI_API_KEY` sea válida y que el proyecto tenga acceso al modelo configurado.