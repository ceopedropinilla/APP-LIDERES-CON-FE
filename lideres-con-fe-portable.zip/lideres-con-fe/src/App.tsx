import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import { useState } from 'react';
import {
  ClerkLoaded,
  ClerkLoading,
  ClerkProvider,
  Show,
  SignIn,
  SignUp,
  useClerk,
  useUser,
} from '@clerk/react';
import { publishableKeyFromHost } from '@clerk/react/internal';
import { ArrowRight, LogOut, ShieldCheck } from 'lucide-react';
import { Link, Redirect, Route, Router as WouterRouter, Switch } from 'wouter';

import ChatEspiritual from './components/ChatEspiritual';
import InspiracionDiaria from './components/InspiracionDiaria';
import BibliotecaCatolica from './components/BibliotecaCatolica';
import Mayordomia from './components/Mayordomia';
import Gobernanza from './components/Gobernanza';
import BottomNav from './components/BottomNav';

const queryClient = new QueryClient();
const basePath = import.meta.env.BASE_URL.replace(/\/$/, '');
const clerkPubKey = publishableKeyFromHost(
  window.location.hostname,
  import.meta.env.VITE_CLERK_PUBLISHABLE_KEY,
);
const clerkProxyUrl = import.meta.env.VITE_CLERK_PROXY_URL;

const clerkAppearance = {
  cssLayerName: 'clerk',
  options: {
    logoPlacement: 'inside' as const,
    logoLinkUrl: basePath || '/',
    logoImageUrl: `${window.location.origin}${basePath}/logo.svg`,
  },
  variables: {
    colorPrimary: '#26384d',
    colorForeground: '#1d2733',
    colorMutedForeground: '#6f7b87',
    colorBackground: '#ffffff',
    colorInput: '#fbfaf7',
    colorInputForeground: '#1d2733',
    colorNeutral: '#e5e0d7',
    colorDanger: '#b54747',
    fontFamily: 'Plus Jakarta Sans, sans-serif',
    borderRadius: '0.75rem',
  },
  elements: {
    rootBox: 'w-full flex justify-center',
    cardBox: 'bg-white rounded-3xl w-[440px] max-w-full overflow-hidden border border-[#e5e0d7] shadow-[0_24px_80px_rgba(38,56,77,0.12)]',
    card: '!shadow-none !border-0 !bg-transparent !rounded-none',
    footer: '!shadow-none !border-0 !bg-transparent !rounded-none',
    headerTitle: 'text-[#1d2733] font-serif',
    headerSubtitle: 'text-[#6f7b87]',
    socialButtonsBlockButtonText: 'text-[#1d2733]',
    formFieldLabel: 'text-[#394858]',
    footerActionLink: 'text-[#26384d] font-semibold',
    footerActionText: 'text-[#6f7b87]',
    dividerText: 'text-[#6f7b87]',
    formButtonPrimary: 'bg-[#26384d] hover:bg-[#1d2d40] text-white',
    formFieldInput: 'bg-[#fbfaf7] border-[#e5e0d7] text-[#1d2733]',
    socialButtonsBlockButton: 'border-[#e5e0d7] bg-white',
    main: 'gap-5',
  },
};

function Main() {
  const [activeTab, setActiveTab] = useState('chat');
  const { user } = useUser();
  const { signOut } = useClerk();

  const renderTab = () => {
    switch (activeTab) {
      case 'chat': return <ChatEspiritual />;
      case 'daily': return <InspiracionDiaria />;
      case 'library': return <BibliotecaCatolica />;
      case 'stewardship': return <Mayordomia />;
      case 'governance': return <Gobernanza />;
      default: return <ChatEspiritual />;
    }
  };

  return (
    <div className="min-h-[100dvh] w-full bg-[#eeeae2] text-foreground font-sans flex justify-center selection:bg-primary/20">
      <div className="w-full max-w-[600px] h-[100dvh] flex flex-col relative bg-background shadow-[0_0_60px_rgb(0,0,0,0.05)] overflow-hidden">
        <header className="absolute top-0 left-0 right-0 z-30 flex items-center justify-between px-5 pt-4 pointer-events-none">
          <div className="pointer-events-auto flex items-center gap-2 rounded-full border border-border/70 bg-white/85 px-3 py-2 shadow-sm backdrop-blur-md">
            <div className="flex h-7 w-7 items-center justify-center rounded-full bg-secondary text-primary">
              <ShieldCheck size={15} />
            </div>
            <span className="max-w-[130px] truncate text-[11px] font-semibold text-foreground">
              {user?.firstName || user?.emailAddresses[0]?.emailAddress || 'Tu espacio'}
            </span>
          </div>
          <button
            type="button"
            onClick={() => signOut({ redirectUrl: basePath || '/' })}
            className="pointer-events-auto flex h-10 w-10 items-center justify-center rounded-full border border-border/70 bg-white/85 text-muted-foreground shadow-sm backdrop-blur-md transition-colors hover:text-foreground"
            aria-label="Cerrar sesión"
          >
            <LogOut size={16} />
          </button>
        </header>
        <main className="flex-1 overflow-y-auto h-full scroll-smooth">
          {renderTab()}
        </main>
        <BottomNav activeTab={activeTab} onChange={setActiveTab} />
      </div>
    </div>
  );
}

function LandingPage() {
  return (
    <div className="min-h-[100dvh] bg-[#eeeae2] px-5 py-8 text-foreground">
      <div className="mx-auto flex min-h-[calc(100dvh-4rem)] w-full max-w-[1080px] flex-col justify-between overflow-hidden rounded-[2rem] border border-border/70 bg-background shadow-[0_24px_80px_rgba(38,56,77,0.12)]">
        <div className="flex items-center justify-between px-6 py-5 sm:px-10">
          <div className="flex items-center gap-3">
            <img src={`${basePath}/logo.svg`} alt="" className="h-9 w-6 object-contain" />
            <span className="font-serif text-lg">Líderes con Fe</span>
          </div>
          <Link href="/sign-in" className="text-sm font-semibold text-primary transition-opacity hover:opacity-70">
            Iniciar sesión
          </Link>
        </div>
        <div className="grid gap-12 px-6 pb-14 pt-12 sm:px-16 sm:pb-20 lg:grid-cols-[1.1fr_0.9fr] lg:items-center">
          <div className="max-w-xl">
            <p className="mb-5 text-[11px] font-bold uppercase tracking-[0.26em] text-primary/70">Una pausa para decidir mejor</p>
            <h1 className="max-w-2xl font-serif text-5xl leading-[1.06] tracking-tight text-foreground sm:text-7xl">
              Lidera tu empresa con propósito.
            </h1>
            <p className="mt-7 max-w-lg text-base leading-8 text-muted-foreground sm:text-lg">
              Un espacio privado para orar, discernir y administrar tus decisiones empresariales a la luz de la fe católica.
            </p>
            <div className="mt-9 flex flex-wrap gap-3">
              <Link href="/sign-up" className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground shadow-lg shadow-primary/15 transition-transform hover:-translate-y-0.5">
                Crear mi cuenta <ArrowRight size={16} />
              </Link>
              <Link href="/sign-in" className="inline-flex items-center rounded-full border border-border bg-white px-5 py-3 text-sm font-semibold text-foreground transition-colors hover:bg-secondary">
                Ya tengo una cuenta
              </Link>
            </div>
          </div>
          <div className="relative mx-auto w-full max-w-sm">
            <div className="absolute -inset-5 rounded-[2rem] bg-secondary/70 blur-2xl" />
            <div className="relative rounded-[1.7rem] border border-primary/10 bg-primary p-7 text-primary-foreground shadow-2xl shadow-primary/20">
              <div className="flex items-center justify-between border-b border-white/15 pb-5">
                <span className="text-[11px] font-bold uppercase tracking-[0.22em] text-white/65">Recordatorio diario</span>
                <span className="rounded-full bg-white/10 px-3 py-1 text-[10px] text-white/70">07:00</span>
              </div>
              <p className="mt-9 font-serif text-3xl leading-tight">“Encomienda al Señor tus obras, y tus planes se cumplirán.”</p>
              <p className="mt-5 text-sm font-semibold text-white/70">Proverbios 16:3</p>
              <div className="mt-10 rounded-2xl bg-white/10 p-4 text-sm leading-6 text-white/80">
                Antes de abrir la agenda, presenta tus decisiones en oración.
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

function AuthPage({ mode }: { mode: 'sign-in' | 'sign-up' }) {
  return (
    <div className="flex min-h-[100dvh] items-center justify-center bg-[#eeeae2] px-4 py-8">
      {mode === 'sign-in' ? (
        <SignIn routing="path" path={`${basePath}/sign-in`} signUpUrl={`${basePath}/sign-up`} />
      ) : (
        <SignUp routing="path" path={`${basePath}/sign-up`} signInUrl={`${basePath}/sign-in`} />
      )}
    </div>
  );
}

function AuthenticatedApp() {
  return (
    <Show when="signed-in">
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Main />
          <Toaster />
        </TooltipProvider>
      </QueryClientProvider>
    </Show>
  );
}

function AppRoutes() {
  return (
    <Switch>
      <Route path="/" component={() => (
        <>
          <Show when="signed-in"><Redirect to="/app" /></Show>
          <Show when="signed-out"><LandingPage /></Show>
        </>
      )} />
      <Route path="/sign-in/*?" component={() => <AuthPage mode="sign-in" />} />
      <Route path="/sign-up/*?" component={() => <AuthPage mode="sign-up" />} />
      <Route path="/app" component={AuthenticatedApp} />
      <Route><Redirect to="/" /></Route>
    </Switch>
  );
}

function App() {
  if (!clerkPubKey) {
    throw new Error('Missing VITE_CLERK_PUBLISHABLE_KEY in the environment.');
  }

  return (
    <WouterRouter base={basePath}>
      <ClerkProvider
        publishableKey={clerkPubKey}
        proxyUrl={clerkProxyUrl}
        appearance={clerkAppearance}
        signInUrl={`${basePath}/sign-in`}
        signUpUrl={`${basePath}/sign-up`}
        localization={{
          signIn: { start: { title: 'Bienvenido de nuevo', subtitle: 'Entra a tu espacio de discernimiento' } },
          signUp: { start: { title: 'Crea tu espacio', subtitle: 'Comienza a liderar desde la fe' } },
        }}
      >
        <ClerkLoading>
          <div className="flex min-h-[100dvh] items-center justify-center bg-[#eeeae2] text-sm text-muted-foreground">Preparando tu espacio...</div>
        </ClerkLoading>
        <ClerkLoaded>
          <AppRoutes />
        </ClerkLoaded>
      </ClerkProvider>
    </WouterRouter>
  );
}

export default App;