import { useState, useEffect } from 'react';
import { Check } from 'lucide-react';
import * as Progress from '@radix-ui/react-progress';

const checklistData = [
  {
    category: 'Transparencia Fiscal',
    items: [
      { id: 'irs_ein', label: 'EIN y registro corporativo vigente' },
      { id: 'taxes_q', label: 'Impuestos trimestrales programados y pagados' },
      { id: 'forms_1099', label: 'Formularios 1099 para contratistas emitidos a tiempo' },
      { id: 'commingling', label: 'Estricta separación de fondos personales y de negocio' },
    ]
  },
  {
    category: 'Cumplimiento Legal',
    items: [
      { id: 'llc_active', label: 'Entidad corporativa (LLC/Corp) en "Good Standing"' },
      { id: 'contracts', label: 'Contratos formales con clientes y proveedores clave' },
      { id: 'insurance', label: 'Seguro de responsabilidad civil y profesional activo' },
    ]
  },
  {
    category: 'Ética Empresarial Católica',
    items: [
      { id: 'fair_wage', label: 'Pago de un salario justo y puntual a los empleados' },
      { id: 'rest_day', label: 'Respeto al domingo como día de descanso familiar y espiritual' },
      { id: 'ethical_supply', label: 'Proveedores verificados éticamente (sin explotación humana)' },
      { id: 'truth_ads', label: 'Marketing honesto sin manipulación emocional o engaño' },
    ]
  },
  {
    category: 'Mayordomía Financiera',
    items: [
      { id: 'budget', label: 'Presupuesto anual definido y monitoreado mensualmente' },
      { id: 'reserves', label: 'Mantenimiento de 3-6 meses de reserva operativa' },
      { id: 'giving', label: 'Política de donaciones y caridad corporativa establecida' },
    ]
  }
];

export default function Gobernanza() {
  const [completed, setCompleted] = useState<Record<string, boolean>>({});
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    const saved = localStorage.getItem('lideres_gobernanza');
    if (saved) {
      try {
        setCompleted(JSON.parse(saved));
      } catch (e) {
        console.error("Failed to parse checklist state");
      }
    }
    setMounted(true);
  }, []);

  const toggleItem = (id: string) => {
    setCompleted(prev => {
      const next = { ...prev, [id]: !prev[id] };
      localStorage.setItem('lideres_gobernanza', JSON.stringify(next));
      return next;
    });
  };

  const totalItems = checklistData.reduce((acc, cat) => acc + cat.items.length, 0);
  const completedItems = Object.values(completed).filter(Boolean).length;
  const progressPercent = Math.round((completedItems / totalItems) * 100) || 0;

  if (!mounted) return null;

  return (
    <div className="p-6 max-w-lg mx-auto w-full animate-in fade-in duration-500">
      <div className="mb-8 mt-4 text-center">
        <h1 className="text-3xl font-serif text-foreground mb-2">Gobernanza</h1>
        <p className="text-muted-foreground text-sm mb-6">Orden y justicia en la administración de tu empresa.</p>
        
        <div className="bg-card border border-border p-5 rounded-2xl shadow-sm text-left">
          <div className="flex justify-between items-end mb-4">
            <div>
              <p className="text-xs font-semibold text-primary uppercase tracking-wider mb-1">Progreso General</p>
              <p className="text-2xl font-serif">{completedItems} <span className="text-sm text-muted-foreground font-sans">/ {totalItems}</span></p>
            </div>
            <span className="text-2xl font-bold text-foreground/90">{progressPercent}%</span>
          </div>
          <Progress.Root className="relative overflow-hidden bg-border/60 rounded-full w-full h-2.5">
            <Progress.Indicator 
              className="bg-primary w-full h-full transition-transform duration-700 ease-out" 
              style={{ transform: `translateX(-${100 - progressPercent}%)` }} 
            />
          </Progress.Root>
        </div>
      </div>

      <div className="space-y-6">
        {checklistData.map((section, idx) => {
          const catTotal = section.items.length;
          const catCompleted = section.items.filter(i => completed[i.id]).length;
          const allCatDone = catTotal === catCompleted;
          
          return (
            <div key={idx} className={`bg-card border transition-colors duration-300 rounded-2xl overflow-hidden shadow-sm ${allCatDone ? 'border-primary/40 bg-primary/5' : 'border-border'}`}>
              <div className="px-5 py-3.5 border-b border-border flex justify-between items-center bg-background/50">
                <h3 className={`font-serif font-medium transition-colors ${allCatDone ? 'text-primary' : 'text-foreground'}`}>
                  {section.category}
                </h3>
                <span className={`text-xs font-bold px-2.5 py-1 rounded-full border transition-colors ${
                  allCatDone 
                    ? 'bg-primary text-primary-foreground border-primary' 
                    : 'bg-background text-muted-foreground border-border'
                }`}>
                  {catCompleted}/{catTotal}
                </span>
              </div>
              <div className="p-2 space-y-1">
                {section.items.map(item => {
                  const isChecked = !!completed[item.id];
                  return (
                    <label 
                      key={item.id} 
                      className="flex items-start gap-3.5 p-3 rounded-xl cursor-pointer transition-colors hover:bg-background/80 group"
                    >
                      <div className="mt-0.5 relative shrink-0">
                        <input
                          type="checkbox"
                          className="sr-only"
                          checked={isChecked}
                          onChange={() => toggleItem(item.id)}
                        />
                        <div className={`w-5 h-5 rounded-md border flex items-center justify-center transition-all duration-200 ${
                          isChecked 
                            ? 'bg-primary border-primary text-primary-foreground' 
                            : 'bg-background border-muted-foreground/40 group-hover:border-primary/50'
                        }`}>
                          <Check size={14} strokeWidth={3} className={`transition-opacity duration-200 ${isChecked ? 'opacity-100' : 'opacity-0'}`} />
                        </div>
                      </div>
                      <span className={`text-sm leading-snug transition-all duration-200 select-none ${isChecked ? 'line-through text-muted-foreground' : 'text-foreground/90'}`}>
                        {item.label}
                      </span>
                    </label>
                  );
                })}
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
