import { useGetDailyInspiration } from '@workspace/api-client-react';
import { Bell, BellOff, BookOpen, Loader2, Moon, Sun } from 'lucide-react';
import logoSvg from '../assets/logo.svg?raw';
import { useEffect, useState } from 'react';

export default function InspiracionDiaria() {
  const { data, isLoading, error } = useGetDailyInspiration();
  const [notificationState, setNotificationState] = useState<NotificationPermission | 'unsupported'>(
    typeof window !== 'undefined' && 'Notification' in window ? Notification.permission : 'unsupported',
  );

  useEffect(() => {
    if (!data || typeof window === 'undefined' || !('Notification' in window)) return;
    if (Notification.permission !== 'granted') return;

    const hour = new Date().getHours();
    const isMorning = hour >= 5 && hour < 12;
    const isEvening = hour >= 19 || hour < 5;
    if (isMorning || isEvening) {
      const title = isMorning ? 'Líderes con Fe · Mañana' : 'Líderes con Fe · Noche';
      const body = isMorning ? data.morningMessage : data.eveningMessage;
      new Notification(title, { body });
    }
  }, [data]);

  const enableNotifications = async () => {
    if (typeof window === 'undefined' || !('Notification' in window)) {
      setNotificationState('unsupported');
      return;
    }
    const permission = await Notification.requestPermission();
    setNotificationState(permission);
  };

  return (
    <div className="px-6 py-12 min-h-[100dvh] flex flex-col items-center justify-center bg-background relative pb-32 animate-in fade-in duration-1000">
      
      {isLoading ? (
        <div className="flex flex-col items-center gap-6">
          <Loader2 className="w-8 h-8 animate-spin text-primary/40" strokeWidth={1.5} />
          <p className="text-[13px] tracking-widest uppercase text-muted-foreground font-medium animate-pulse">Inspirando...</p>
        </div>
      ) : error ? (
        <div className="text-center p-8 bg-white border border-border rounded-xl max-w-sm shadow-sm">
          <p className="text-[14px] text-foreground font-medium">No se pudo cargar la inspiración.</p>
          <p className="text-[13px] text-muted-foreground mt-2">Por favor, intenta nuevamente más tarde.</p>
        </div>
      ) : data ? (
        <div className="max-w-lg w-full flex flex-col items-center">
          <div className="mb-12 opacity-80">
            <div dangerouslySetInnerHTML={{ __html: logoSvg }} className="w-10 h-10 [&_path]:fill-primary mx-auto" />
          </div>

          <div className="mb-5 flex w-full items-center justify-between rounded-2xl border border-border/70 bg-white px-4 py-3 shadow-sm">
            <div className="flex items-center gap-3">
              <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-secondary text-primary">
                {notificationState === 'granted' ? <Bell size={17} /> : <BellOff size={17} />}
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">Recordatorios diarios</p>
                <p className="text-[11px] text-muted-foreground">
                  {notificationState === 'granted' ? 'Activos mientras visitas la app' : 'Recibe un aviso al abrir tu día'}
                </p>
              </div>
            </div>
            {notificationState === 'granted' ? (
              <span className="text-[10px] font-bold uppercase tracking-wider text-primary">Activos</span>
            ) : notificationState === 'unsupported' ? (
              <span className="text-[10px] text-muted-foreground">No disponible</span>
            ) : (
              <button type="button" onClick={enableNotifications} className="rounded-full bg-primary px-3 py-2 text-[10px] font-bold text-primary-foreground">
                Activar
              </button>
            )}
          </div>

          <div className="w-full bg-white px-8 py-10 sm:px-12 sm:py-12 rounded-3xl shadow-[0_4px_40px_rgb(0,0,0,0.03)] border border-black/[0.03] relative overflow-hidden">
            {/* Elegant top accent line */}
            <div className="absolute top-0 left-1/2 -translate-x-1/2 w-24 h-[2px] bg-primary/20"></div>
            
            <div className="flex justify-center mb-8 relative z-10">
              <span className="inline-block text-primary text-[10px] font-bold tracking-[0.25em] uppercase">
                {data.category}
              </span>
            </div>

            <div className="text-center relative z-10 mb-10">
              <h2 className="text-[26px] sm:text-[32px] font-serif text-foreground leading-[1.4] tracking-tight">
                "{data.verse}"
              </h2>
            </div>

            <div className="flex items-center justify-center gap-4 mb-10 opacity-70">
              <div className="h-[1px] w-12 bg-border"></div>
              <p className="text-foreground text-[12px] font-medium tracking-[0.1em] uppercase">
                {data.reference}
              </p>
              <div className="h-[1px] w-12 bg-border"></div>
            </div>

            <div className="relative z-10 p-6 sm:p-8 bg-secondary/30 rounded-2xl">
              <p className="text-foreground/80 text-[15px] sm:text-[16px] leading-[1.8] text-center font-serif italic">
                {data.reflection}
              </p>
            </div>
          </div>

          <div className="mt-5 grid w-full gap-4 sm:grid-cols-2">
            <div className="rounded-2xl border border-border/70 bg-white p-5 shadow-sm">
              <div className="mb-3 flex items-center gap-2 text-primary">
                <Sun size={16} />
                <span className="text-[10px] font-bold uppercase tracking-[0.18em]">Al comenzar</span>
              </div>
              <p className="text-sm leading-6 text-foreground/80">{data.morningMessage}</p>
            </div>
            <div className="rounded-2xl border border-border/70 bg-white p-5 shadow-sm">
              <div className="mb-3 flex items-center gap-2 text-primary">
                <BookOpen size={16} />
                <span className="text-[10px] font-bold uppercase tracking-[0.18em]">Finanzas con fe</span>
              </div>
              <p className="text-sm leading-6 text-foreground/80">{data.financialAdvice}</p>
            </div>
            <div className="rounded-2xl border border-primary/10 bg-primary p-5 text-primary-foreground shadow-sm sm:col-span-2">
              <div className="mb-3 flex items-center gap-2 text-white/75">
                <Moon size={16} />
                <span className="text-[10px] font-bold uppercase tracking-[0.18em]">Antes de descansar</span>
              </div>
              <p className="text-sm leading-6 text-white/85">{data.eveningMessage}</p>
            </div>
          </div>
        </div>
      ) : null}
    </div>
  );
}
