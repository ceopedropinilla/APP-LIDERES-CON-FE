import { useState } from 'react';
import { DollarSign } from 'lucide-react';
import * as Slider from '@radix-ui/react-slider';

export default function Mayordomia() {
  const [ingresos, setIngresos] = useState<string>('');
  const [gastos, setGastos] = useState<string>('');
  const [diezmo, setDiezmo] = useState<number>(10);
  const [reserva, setReserva] = useState<number>(15);

  const parsedIngresos = parseFloat(ingresos) || 0;
  const parsedGastos = parseFloat(gastos) || 0;
  const gananciaBruta = Math.max(0, parsedIngresos - parsedGastos);
  
  const montoDiezmo = gananciaBruta * (diezmo / 100);
  const montoReserva = gananciaBruta * (reserva / 100);
  const disponible = gananciaBruta - montoDiezmo - montoReserva;

  const formatCurrency = (val: number) => 
    new Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(val);

  return (
    <div className="p-6 max-w-lg mx-auto w-full animate-in fade-in duration-500">
      <div className="mb-8 mt-4 text-center">
        <h1 className="text-3xl font-serif text-foreground mb-2">Mayordomía</h1>
        <p className="text-muted-foreground text-sm">Administrar los bienes como dones de Dios.</p>
      </div>

      <div className="bg-primary/5 rounded-2xl p-5 mb-8 border border-primary/10">
        <h3 className="font-serif text-xl mb-4 text-foreground text-center">Mentalidad de Reino</h3>
        <div className="grid grid-cols-2 gap-4 text-sm">
          <div className="space-y-2 bg-background/50 p-3 rounded-xl">
            <h4 className="font-bold text-muted-foreground uppercase text-[10px] tracking-wider mb-2 text-center">Secular</h4>
            <ul className="space-y-3 text-foreground/70 text-xs">
              <li className="flex items-start gap-1.5"><span className="text-destructive/70 text-sm leading-none mt-0.5">&times;</span> Acumulación personal prioritaria</li>
              <li className="flex items-start gap-1.5"><span className="text-destructive/70 text-sm leading-none mt-0.5">&times;</span> El dinero es el fin último</li>
              <li className="flex items-start gap-1.5"><span className="text-destructive/70 text-sm leading-none mt-0.5">&times;</span> Control basado en ansiedad</li>
            </ul>
          </div>
          <div className="space-y-2 bg-primary/10 p-3 rounded-xl border border-primary/20">
            <h4 className="font-bold text-primary uppercase text-[10px] tracking-wider mb-2 text-center">Católica</h4>
            <ul className="space-y-3 text-foreground/90 text-xs">
              <li className="flex items-start gap-1.5"><span className="text-primary text-sm leading-none mt-0.5">&check;</span> Enfoque en el bien común</li>
              <li className="flex items-start gap-1.5"><span className="text-primary text-sm leading-none mt-0.5">&check;</span> El dinero es solo un medio</li>
              <li className="flex items-start gap-1.5"><span className="text-primary text-sm leading-none mt-0.5">&check;</span> Confianza en la Providencia</li>
            </ul>
          </div>
        </div>
      </div>

      <div className="bg-card rounded-2xl border border-border p-6 shadow-sm">
        <h3 className="font-serif text-xl mb-1 text-foreground">Calculadora Financiera</h3>
        <p className="text-xs text-muted-foreground mb-6">Planifica la distribución de tus utilidades mensuales.</p>

        <div className="space-y-5">
          <div>
            <label className="text-xs font-semibold text-foreground/80 mb-1.5 block uppercase tracking-wide">Ingresos Mensuales</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={16} />
              <input 
                type="number" 
                value={ingresos}
                onChange={(e) => setIngresos(e.target.value)}
                placeholder="0.00"
                className="w-full bg-background border border-border rounded-xl py-2.5 pl-9 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-primary/50 font-mono"
              />
            </div>
          </div>
          <div>
            <label className="text-xs font-semibold text-foreground/80 mb-1.5 block uppercase tracking-wide">Gastos Operativos</label>
            <div className="relative">
              <DollarSign className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground" size={16} />
              <input 
                type="number" 
                value={gastos}
                onChange={(e) => setGastos(e.target.value)}
                placeholder="0.00"
                className="w-full bg-background border border-border rounded-xl py-2.5 pl-9 pr-4 text-sm focus:outline-none focus:ring-1 focus:ring-primary/50 font-mono"
              />
            </div>
          </div>
          
          <div className="pt-3">
            <div className="flex justify-between items-center mb-3">
              <label className="text-xs font-semibold text-foreground/80 uppercase tracking-wide">Diezmo / Donaciones</label>
              <span className="text-sm font-mono font-bold text-primary bg-primary/10 px-2 py-0.5 rounded">{diezmo}%</span>
            </div>
            <Slider.Root 
              className="relative flex items-center select-none touch-none w-full h-5 cursor-pointer"
              value={[diezmo]}
              max={30}
              step={1}
              onValueChange={([val]) => setDiezmo(val)}
            >
              <Slider.Track className="bg-border relative grow rounded-full h-1.5 overflow-hidden">
                <Slider.Range className="absolute bg-primary h-full" />
              </Slider.Track>
              <Slider.Thumb className="block w-5 h-5 bg-background border-2 border-primary shadow-sm rounded-full focus:outline-none focus:ring-2 focus:ring-primary/30 transition-colors" />
            </Slider.Root>
          </div>

          <div className="pt-2">
            <div className="flex justify-between items-center mb-3">
              <label className="text-xs font-semibold text-foreground/80 uppercase tracking-wide">Reserva de Emergencia</label>
              <span className="text-sm font-mono font-bold text-primary bg-primary/10 px-2 py-0.5 rounded">{reserva}%</span>
            </div>
            <Slider.Root 
              className="relative flex items-center select-none touch-none w-full h-5 cursor-pointer"
              value={[reserva]}
              max={50}
              step={1}
              onValueChange={([val]) => setReserva(val)}
            >
              <Slider.Track className="bg-border relative grow rounded-full h-1.5 overflow-hidden">
                <Slider.Range className="absolute bg-primary h-full" />
              </Slider.Track>
              <Slider.Thumb className="block w-5 h-5 bg-background border-2 border-primary shadow-sm rounded-full focus:outline-none focus:ring-2 focus:ring-primary/30 transition-colors" />
            </Slider.Root>
          </div>

          <div className="mt-8 p-5 bg-background border border-border rounded-xl space-y-3 shadow-inner">
            <div className="flex justify-between items-center pb-3 border-b border-border/60">
              <span className="text-sm font-medium text-foreground">Ganancia Neta</span>
              <span className="font-mono font-bold">{formatCurrency(gananciaBruta)}</span>
            </div>
            <div className="flex justify-between items-center text-sm">
              <span className="text-muted-foreground">Donaciones ({diezmo}%)</span>
              <span className="font-mono text-primary font-medium">{formatCurrency(montoDiezmo)}</span>
            </div>
            <div className="flex justify-between items-center text-sm pb-3 border-b border-border/60">
              <span className="text-muted-foreground">Reserva ({reserva}%)</span>
              <span className="font-mono font-medium">{formatCurrency(montoReserva)}</span>
            </div>
            <div className="flex justify-between items-center pt-2">
              <span className="text-sm font-bold text-foreground">Disponible / Inversión</span>
              <span className="font-mono font-bold text-xl text-primary">{formatCurrency(disponible)}</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
