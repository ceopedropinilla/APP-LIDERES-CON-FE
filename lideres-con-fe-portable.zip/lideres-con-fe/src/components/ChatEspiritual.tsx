import { useState, useRef, useEffect } from 'react';
import { useSendChatMessage } from '@workspace/api-client-react';
import { Send, BookOpen, Quote } from 'lucide-react';
import logoSvg from '../assets/logo.svg?raw';

export default function ChatEspiritual() {
  const [messages, setMessages] = useState<{role: 'user'|'assistant', content: string, references?: string[], prayer?: string}[]>([
    { role: 'assistant', content: 'Bienvenido. Soy tu acompañante espiritual para tu empresa. ¿Qué inquietud o decisión tienes hoy en tu negocio que quieras poner en oración y a la luz de la Palabra?' }
  ]);
  const [input, setInput] = useState('');
  const bottomRef = useRef<HTMLDivElement>(null);
  
  const chatMutation = useSendChatMessage();

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages, chatMutation.isPending]);

  const handleSend = () => {
    if (!input.trim() || chatMutation.isPending) return;
    
    const userMsg = input.trim();
    setInput('');
    const newHistory = [...messages, { role: 'user' as const, content: userMsg }];
    setMessages(newHistory);
    
    // Convert generic 'user' | 'assistant' to the exact type expected by Orval
    const mappedHistory = messages.map(m => ({ 
      role: m.role as "user" | "assistant", 
      content: m.content 
    }));

    chatMutation.mutate(
      { data: { message: userMsg, history: mappedHistory } },
      {
        onSuccess: (data) => {
          setMessages(prev => [...prev, { 
            role: 'assistant', 
            content: data.message,
            references: data.references,
            prayer: data.prayer
          }]);
        },
        onError: () => {
          setMessages(prev => [...prev, { 
            role: 'assistant', 
            content: 'Lo siento, ha ocurrido un error al procesar tu mensaje. Por favor, intenta de nuevo.' 
          }]);
        }
      }
    );
  };

  return (
    <div className="flex flex-col min-h-[100dvh] bg-background">
      <div className="flex-1 px-5 pt-8 pb-40 space-y-8 max-w-3xl mx-auto w-full">
        {/* Header */}
        <div className="flex flex-col items-center justify-center py-12 text-center animate-in fade-in slide-in-from-bottom-4 duration-700">
          <div className="w-16 h-16 bg-white border border-border/60 rounded-2xl flex items-center justify-center mb-6 shadow-sm">
            <div dangerouslySetInnerHTML={{ __html: logoSvg }} className="w-8 h-8 [&_path]:fill-primary" />
          </div>
          <h2 className="text-2xl font-serif text-foreground mb-2 tracking-tight">Líderes con Fe</h2>
          <p className="text-[14px] text-muted-foreground max-w-[280px] leading-relaxed">Discernimiento para tu vocación empresarial</p>
        </div>

        <div className="space-y-8">
          {messages.map((msg, idx) => {
            const isUser = msg.role === 'user';
            
            // Cleanup repeated prayer from content to prevent "repetida" feeling
            let displayContent = msg.content;
            if (!isUser && msg.prayer) {
              const cleanedPrayer = msg.prayer.replace(/^["']|["']$/g, '').trim();
              if (displayContent.includes(cleanedPrayer)) {
                displayContent = displayContent.replace(cleanedPrayer, '').trim();
                // Also remove trailing quotes or commas if left behind
                displayContent = displayContent.replace(/["',:]*$/, '').trim();
              }
            }

            return (
              <div 
                key={idx} 
                className={`flex w-full ${isUser ? 'justify-end' : 'justify-start'} animate-stagger-message`}
                style={{ animationDelay: `${Math.min(idx * 0.05, 0.5)}s` }}
              >
                {!isUser && (
                  <div className="w-8 h-8 rounded-full bg-white border border-border/60 flex items-center justify-center shrink-0 mr-3 mt-1 shadow-sm">
                    <div dangerouslySetInnerHTML={{ __html: logoSvg }} className="w-4 h-4 [&_path]:fill-primary" />
                  </div>
                )}
                
                <div className={`max-w-[85%] md:max-w-[75%] flex flex-col gap-3 ${
                  isUser ? 'items-end' : 'items-start'
                }`}>
                  {/* Main Content Bubble */}
                  {displayContent && (
                    <div className={`px-5 py-4 rounded-2xl text-[15px] leading-[1.6] shadow-sm ${
                      isUser 
                        ? 'bg-primary text-white rounded-tr-sm' 
                        : 'bg-white text-foreground rounded-tl-sm border border-border/40'
                    }`}>
                      <p className="whitespace-pre-wrap">{displayContent}</p>
                    </div>
                  )}
                  
                  {/* References Block */}
                  {!isUser && msg.references && msg.references.length > 0 && (
                    <div className="bg-secondary/40 border border-secondary px-5 py-4 rounded-xl w-full">
                      <div className="flex items-center gap-2 mb-3">
                        <BookOpen size={14} className="text-primary/70" />
                        <span className="text-[11px] font-bold uppercase tracking-widest text-primary/80">
                          A la luz de la Palabra
                        </span>
                      </div>
                      <ul className="space-y-2">
                        {msg.references.map((ref, i) => (
                          <li key={i} className="text-[13px] text-foreground/80 leading-relaxed pl-3 relative before:content-[''] before:absolute before:left-0 before:top-2 before:w-1 before:h-1 before:bg-primary/40 before:rounded-full">
                            {ref}
                          </li>
                        ))}
                      </ul>
                    </div>
                  )}

                  {/* Prayer Block */}
                  {!isUser && msg.prayer && (
                    <div className="bg-white border border-border/40 px-6 py-5 rounded-xl w-full relative overflow-hidden mt-1 shadow-sm">
                      <div className="absolute top-0 left-0 w-1 h-full bg-accent"></div>
                      <div className="flex items-center gap-2 mb-3">
                        <Quote size={14} className="text-accent-foreground/50" />
                        <span className="text-[11px] font-bold uppercase tracking-widest text-muted-foreground">
                          Oración propuesta
                        </span>
                      </div>
                      <p className="text-[15px] font-serif italic text-foreground/90 leading-relaxed">
                        "{msg.prayer.replace(/^["']|["']$/g, '')}"
                      </p>
                    </div>
                  )}
                </div>
              </div>
            );
          })}
          
          {chatMutation.isPending && (
            <div className="flex w-full justify-start animate-in fade-in duration-300">
              <div className="w-8 h-8 rounded-full bg-white border border-border/60 flex items-center justify-center shrink-0 mr-3 shadow-sm">
                <div dangerouslySetInnerHTML={{ __html: logoSvg }} className="w-4 h-4 [&_path]:fill-primary" />
              </div>
              <div className="bg-white border border-border/40 rounded-2xl rounded-tl-sm px-5 py-5 shadow-sm flex items-center gap-2">
                <div className="flex gap-1.5">
                  <div className="w-1.5 h-1.5 bg-primary/40 rounded-full animate-bounce"></div>
                  <div className="w-1.5 h-1.5 bg-primary/40 rounded-full animate-bounce [animation-delay:0.2s]"></div>
                  <div className="w-1.5 h-1.5 bg-primary/40 rounded-full animate-bounce [animation-delay:0.4s]"></div>
                </div>
              </div>
            </div>
          )}
          
          <div ref={bottomRef} className="h-4" />
        </div>
      </div>

      {/* Input Area */}
      <div className="fixed bottom-[76px] left-0 w-full flex justify-center z-40 bg-gradient-to-t from-background via-background/95 to-transparent pt-10 pb-2 px-4 pointer-events-none">
        <div className="w-full max-w-3xl relative flex items-center pointer-events-auto">
          <div className="relative w-full bg-white shadow-[0_8px_30px_rgb(0,0,0,0.06)] border border-border/80 rounded-2xl transition-all duration-300 focus-within:shadow-[0_8px_40px_rgb(0,0,0,0.08)] focus-within:border-primary/30">
            <textarea 
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={(e) => {
                if (e.key === 'Enter' && !e.shiftKey) {
                  e.preventDefault();
                  handleSend();
                }
              }}
              placeholder="Escribe tu inquietud o situación..."
              className="w-full bg-transparent py-4 pl-5 pr-14 text-[15px] focus:outline-none resize-none max-h-32 min-h-[56px] text-foreground placeholder:text-muted-foreground/60 rounded-2xl"
              rows={1}
            />
            <button 
              onClick={handleSend}
              disabled={!input.trim() || chatMutation.isPending}
              className="absolute right-2 bottom-2 p-2.5 bg-primary text-white rounded-xl hover:bg-primary/90 disabled:opacity-50 disabled:hover:bg-primary transition-all duration-200"
            >
              <Send size={18} className={`${input.trim() ? 'translate-x-[1px] -translate-y-[1px]' : ''} transition-transform`} />
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
