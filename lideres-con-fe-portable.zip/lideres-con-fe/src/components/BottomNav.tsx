import { MessageCircle, Sun, BookOpen, Scale, Shield } from 'lucide-react';
import logoSvg from '../assets/logo.svg?raw';

interface BottomNavProps {
  activeTab: string;
  onChange: (tab: string) => void;
}

const tabs = [
  { id: 'chat', icon: MessageCircle, label: 'Chat', isLogo: true },
  { id: 'daily', icon: Sun, label: 'Diario' },
  { id: 'library', icon: BookOpen, label: 'Docs' },
  { id: 'stewardship', icon: Scale, label: 'Gestión' },
  { id: 'governance', icon: Shield, label: 'Gobierno' },
];

export default function BottomNav({ activeTab, onChange }: BottomNavProps) {
  return (
    <div className="fixed bottom-0 left-0 w-full z-50 pb-4 pt-12 px-4 pointer-events-none flex justify-center bg-gradient-to-t from-background via-background/95 to-transparent">
      <nav className="pointer-events-auto bg-white/90 dark:bg-card/90 backdrop-blur-md shadow-[0_8px_40px_rgb(0,0,0,0.06)] border border-border/60 px-3 py-2.5 rounded-2xl flex justify-between items-center w-full max-w-[420px]">
        {tabs.map((tab) => {
          const isActive = activeTab === tab.id;
          const Icon = tab.icon;
          return (
            <button
              key={tab.id}
              onClick={() => onChange(tab.id)}
              className="relative flex flex-col items-center justify-center w-[64px] group"
            >
              <div className={`p-2 rounded-xl transition-colors duration-300 ${isActive ? 'bg-secondary' : 'bg-transparent'}`}>
                {tab.isLogo ? (
                  <div 
                    dangerouslySetInnerHTML={{ __html: logoSvg }} 
                    className={`w-5 h-5 flex items-center justify-center transition-colors duration-300 ${isActive ? '[&_path]:fill-primary' : '[&_path]:fill-muted-foreground group-hover:[&_path]:fill-foreground'}`} 
                  />
                ) : (
                  <Icon 
                    size={20} 
                    strokeWidth={isActive ? 2.5 : 2} 
                    className={`transition-colors duration-300 ${isActive ? 'text-primary' : 'text-muted-foreground group-hover:text-foreground'}`}
                  />
                )}
              </div>
              <span className={`text-[9px] mt-1 font-medium tracking-[0.02em] transition-colors duration-300 ${isActive ? 'text-primary' : 'text-muted-foreground'}`}>
                {tab.label}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}
