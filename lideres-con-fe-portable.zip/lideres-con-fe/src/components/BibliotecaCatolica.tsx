import { useState } from 'react';
import { ChevronDown, Book, Users, HeartHandshake } from 'lucide-react';

const libraryData = [
  {
    title: 'Proverbios para Empresarios',
    icon: Book,
    items: [
      { subtitle: 'Prov 16:3', content: 'Pon en manos del Señor todas tus obras, y tus proyectos se cumplirán. Una invitación a soltar el control excesivo y confiar en la providencia.' },
      { subtitle: 'Prov 3:5-6', content: 'Confía en el Señor de todo corazón, y no en tu propia inteligencia. Reconócelo en todos tus caminos, y él allanará tus sendas.' },
      { subtitle: 'Prov 10:4', content: 'Las manos ociosas conducen a la pobreza; las manos hábiles atraen riquezas. El trabajo diligente es honrado y bendecido.' },
      { subtitle: 'Prov 22:29', content: '¿Has visto a alguien diligente en su trabajo? Se codeará con reyes, y nunca será un don nadie. La excelencia como forma de adoración.' },
    ]
  },
  {
    title: 'Doctrina Social de la Iglesia',
    icon: Users,
    items: [
      { subtitle: 'Dignidad Humana', content: 'La persona es el fin último de la sociedad y de la empresa. Ningún empleado o cliente es un mero instrumento para generar ganancias.' },
      { subtitle: 'Bien Común', content: 'La empresa debe contribuir al florecimiento de toda la comunidad, creando bienes y servicios verdaderamente útiles.' },
      { subtitle: 'Subsidiariedad', content: 'Dar autonomía y responsabilidad a los colaboradores. No micro-gestionar lo que otros pueden hacer bien por sí mismos.' },
      { subtitle: 'Solidaridad', content: 'Reconocer la interdependencia. Si la empresa prospera, los colaboradores también deben prosperar.' },
      { subtitle: 'Opción por los Pobres', content: 'Asegurar que las decisiones de negocio no marginen a los más vulnerables, sino que busquen su integración y desarrollo.' }
    ]
  },
  {
    title: 'Encíclicas Clave',
    icon: HeartHandshake,
    items: [
      { subtitle: 'Rerum Novarum (León XIII, 1891)', content: 'Defiende la dignidad del trabajador, la propiedad privada como derecho natural, y el derecho a un salario justo que permita sostener dignamente a una familia.' },
      { subtitle: 'Centesimus Annus (Juan Pablo II, 1991)', content: 'La empresa no es solo una "sociedad de capitales", sino una "sociedad de personas". El beneficio es indicador de buen funcionamiento, pero no el único fin.' },
      { subtitle: 'Caritas in Veritate (Benedicto XVI, 2009)', content: 'Destaca que la economía necesita ética para funcionar correctamente. Propone la lógica del don y la gratuidad dentro de la actividad económica.' },
    ]
  }
];

export default function BibliotecaCatolica() {
  const [openSection, setOpenSection] = useState<number>(0);

  return (
    <div className="p-6 max-w-lg mx-auto w-full animate-in fade-in duration-500">
      <div className="mb-8 mt-4 text-center">
        <h1 className="text-3xl font-serif text-foreground mb-2">Biblioteca</h1>
        <p className="text-muted-foreground text-sm">Sabiduría milenaria para el liderazgo actual.</p>
      </div>

      <div className="space-y-4">
        {libraryData.map((section, idx) => {
          const isOpen = openSection === idx;
          const Icon = section.icon;
          return (
            <div key={idx} className="bg-card rounded-2xl border border-border overflow-hidden transition-all duration-300 shadow-sm">
              <button 
                onClick={() => setOpenSection(isOpen ? -1 : idx)}
                className="w-full px-5 py-4 flex items-center justify-between hover:bg-card/80 transition-colors"
              >
                <div className="flex items-center gap-3 text-left">
                  <div className="p-2 bg-primary/10 text-primary rounded-lg">
                    <Icon size={20} />
                  </div>
                  <span className="font-serif font-medium text-lg text-foreground">{section.title}</span>
                </div>
                <ChevronDown 
                  size={20} 
                  className={`text-muted-foreground transition-transform duration-300 ${isOpen ? 'rotate-180' : ''}`} 
                />
              </button>
              
              <div 
                className={`grid transition-all duration-300 ease-in-out ${isOpen ? 'grid-rows-[1fr] opacity-100' : 'grid-rows-[0fr] opacity-0'}`}
              >
                <div className="overflow-hidden">
                  <div className="p-5 pt-2 space-y-6 bg-background">
                    {section.items.map((item, i) => (
                      <div key={i} className="space-y-1.5 border-l-2 border-primary/20 pl-4">
                        <h4 className="text-sm font-bold text-primary tracking-wide uppercase">{item.subtitle}</h4>
                        <p className="text-sm text-foreground/80 leading-relaxed">{item.content}</p>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </div>
  );
}
