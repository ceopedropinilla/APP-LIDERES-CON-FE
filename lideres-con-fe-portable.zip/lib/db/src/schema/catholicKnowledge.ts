import { createInsertSchema } from "drizzle-zod";
import { pgTable, serial, text, timestamp } from "drizzle-orm/pg-core";
import { z } from "zod/v4";

export const catholicKnowledgeTable = pgTable("catholic_knowledge", {
  id: serial("id").primaryKey(),
  sourceType: text("source_type").notNull(),
  title: text("title").notNull(),
  reference: text("reference").notNull(),
  content: text("content").notNull(),
  keywords: text("keywords").notNull().default(""),
  createdAt: timestamp("created_at", { withTimezone: true }).notNull().defaultNow(),
});

export const insertCatholicKnowledgeSchema = createInsertSchema(
  catholicKnowledgeTable,
).omit({ id: true, createdAt: true });

export type InsertCatholicKnowledge = z.infer<
  typeof insertCatholicKnowledgeSchema
>;
export type CatholicKnowledge = typeof catholicKnowledgeTable.$inferSelect;