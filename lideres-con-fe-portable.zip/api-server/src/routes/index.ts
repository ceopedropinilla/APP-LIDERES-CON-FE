import { Router, type IRouter } from "express";
import healthRouter from "./health";
import chatRouter from "./chat";
import inspirationRouter from "./inspiration";

const router: IRouter = Router();

router.use(healthRouter);
router.use(chatRouter);
router.use(inspirationRouter);

export default router;
