import { clerkClient, getAuth } from "@clerk/express";
import type { RequestHandler } from "express";

export const requireAdmin: RequestHandler = async (req, res, next) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Debes iniciar sesión para continuar." });
    return;
  }

  const adminEmail = process.env.ADMIN_EMAIL;
  if (!adminEmail) {
    res.status(403).json({ error: "Acceso restringido." });
    return;
  }

  try {
    const user = await clerkClient.users.getUser(userId);
    const emails = user.emailAddresses.map((e: { emailAddress: string }) => e.emailAddress);
    if (!emails.includes(adminEmail)) {
      res.status(403).json({ error: "Acceso restringido. Solo el administrador puede ver este recurso." });
      return;
    }
    next();
  } catch {
    res.status(403).json({ error: "Acceso restringido." });
  }
};
