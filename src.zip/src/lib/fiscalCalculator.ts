import { z } from "zod";

export const fiscalInputSchema = z.object({
  taxYear: z.number().int().min(2025).max(2025).default(2025),
  companyType: z.enum([
    "individual",
    "sole_proprietor",
    "partnership",
    "s_corporation",
    "c_corporation",
  ]).default("individual"),
  filingStatus: z.enum([
    "single",
    "married_joint",
    "married_separate",
    "head_of_household",
    "qualifying_widow",
  ]),
  salaryIncome: z.number().min(0).max(100_000_000).default(0),
  businessIncome: z.number().min(0).max(100_000_000).default(0),
  businessExpenses: z.number().min(0).max(100_000_000).default(0),
  otherIncome: z.number().min(0).max(100_000_000).default(0),
  withholding: z.number().min(0).max(100_000_000).default(0),
  estimatedPayments: z.number().min(0).max(100_000_000).default(0),
  dependents: z.number().int().min(0).max(20).default(0),
  dependentsWithSSN: z.number().int().min(0).max(20).optional(),
  dependentsWithITIN: z.number().int().min(0).max(20).optional(),
  otherDeductions: z.number().min(0).max(100_000_000).default(0),
  otherCredits: z.number().min(0).max(100_000_000).default(0),
});

export type FiscalInputs = z.infer<typeof fiscalInputSchema>;

export interface FiscalCalculation {
  taxYear: number;
  adjustedGrossIncome: number;
  businessProfit: number;
  standardDeduction: number;
  deductionUsed: number;
  taxableIncome: number;
  incomeTax: number;
  selfEmploymentTax: number;
  childTaxCredit: number;
  otherDependentCredit: number;
  otherCredits: number;
  estimatedFederalTax: number;
  paymentsAndWithholding: number;
  balance: number;
  estimatedAmount: number;
  result: "reembolso" | "debe_impuestos" | "equilibrado";
  effectiveRate: number;
}

type Bracket = { through: number; rate: number };

const BRACKETS_2025: Record<FiscalInputs["filingStatus"], Bracket[]> = {
  single: [
    { through: 11_925, rate: 0.1 },
    { through: 48_475, rate: 0.12 },
    { through: 103_350, rate: 0.22 },
    { through: 197_300, rate: 0.24 },
    { through: 250_525, rate: 0.32 },
    { through: 626_350, rate: 0.35 },
    { through: Number.POSITIVE_INFINITY, rate: 0.37 },
  ],
  married_joint: [
    { through: 23_850, rate: 0.1 },
    { through: 96_950, rate: 0.12 },
    { through: 206_700, rate: 0.22 },
    { through: 394_600, rate: 0.24 },
    { through: 501_050, rate: 0.32 },
    { through: 751_600, rate: 0.35 },
    { through: Number.POSITIVE_INFINITY, rate: 0.37 },
  ],
  married_separate: [
    { through: 11_925, rate: 0.1 },
    { through: 48_475, rate: 0.12 },
    { through: 103_350, rate: 0.22 },
    { through: 197_300, rate: 0.24 },
    { through: 250_525, rate: 0.32 },
    { through: 375_800, rate: 0.35 },
    { through: Number.POSITIVE_INFINITY, rate: 0.37 },
  ],
  head_of_household: [
    { through: 17_000, rate: 0.1 },
    { through: 64_850, rate: 0.12 },
    { through: 103_350, rate: 0.22 },
    { through: 197_300, rate: 0.24 },
    { through: 250_500, rate: 0.32 },
    { through: 626_350, rate: 0.35 },
    { through: Number.POSITIVE_INFINITY, rate: 0.37 },
  ],
  qualifying_widow: [
    { through: 23_850, rate: 0.1 },
    { through: 96_950, rate: 0.12 },
    { through: 206_700, rate: 0.22 },
    { through: 394_600, rate: 0.24 },
    { through: 501_050, rate: 0.32 },
    { through: 751_600, rate: 0.35 },
    { through: Number.POSITIVE_INFINITY, rate: 0.37 },
  ],
};

const STANDARD_DEDUCTIONS_2025: Record<FiscalInputs["filingStatus"], number> = {
  single: 15_750,
  married_joint: 31_500,
  married_separate: 15_750,
  head_of_household: 23_625,
  qualifying_widow: 31_500,
};

function calculateProgressiveTax(
  taxableIncome: number,
  brackets: Bracket[],
): number {
  let tax = 0;
  let previousLimit = 0;

  for (const bracket of brackets) {
    const amountInBracket = Math.max(
      0,
      Math.min(taxableIncome, bracket.through) - previousLimit,
    );
    tax += amountInBracket * bracket.rate;
    previousLimit = bracket.through;
    if (taxableIncome <= bracket.through) break;
  }

  return tax;
}

export function calculateFiscalSimulation(input: FiscalInputs): FiscalCalculation {
  const businessProfit = Math.max(
    0,
    input.businessIncome - Math.min(input.businessExpenses, input.businessIncome),
  );
  const adjustedGrossIncome =
    input.salaryIncome + businessProfit + input.otherIncome;
  const selfEmploymentTax = businessProfit * 0.9235 * 0.153;
  const deductionForSelfEmploymentTax = selfEmploymentTax / 2;
  const standardDeduction = STANDARD_DEDUCTIONS_2025[input.filingStatus];
  const deductionUsed = Math.max(
    standardDeduction,
    input.otherDeductions,
  );
  const taxableIncome = Math.max(
    0,
    adjustedGrossIncome - deductionUsed - deductionForSelfEmploymentTax,
  );
  const incomeTax = calculateProgressiveTax(
    taxableIncome,
    BRACKETS_2025[input.filingStatus],
  );
  // An ITIN can identify a dependent, but it generally does not qualify
  // for the federal Child Tax Credit. Keep the legacy `dependents` field
  // as a fallback for old saved simulations that predate the SSN/ITIN split.
  const eligibleDependents =
    input.dependentsWithSSN ?? input.dependents;
  const childTaxCredit = Math.min(eligibleDependents * 2_000, incomeTax);
  const otherDependentCredit = Math.min(
    (input.dependentsWithITIN ?? 0) * 500,
    Math.max(0, incomeTax - childTaxCredit),
  );
  const otherCredits = Math.min(
    input.otherCredits,
    Math.max(0, incomeTax - childTaxCredit - otherDependentCredit),
  );
  const estimatedFederalTax = Math.max(
    0,
    incomeTax + selfEmploymentTax - childTaxCredit - otherDependentCredit - otherCredits,
  );
  const paymentsAndWithholding =
    input.withholding + input.estimatedPayments;
  const balance = estimatedFederalTax - paymentsAndWithholding;
  const estimatedAmount = Math.abs(balance);
  const result =
    balance < -50
      ? "reembolso"
      : balance > 50
        ? "debe_impuestos"
        : "equilibrado";

  return {
    taxYear: input.taxYear,
    adjustedGrossIncome: Math.round(adjustedGrossIncome),
    businessProfit: Math.round(businessProfit),
    standardDeduction,
    deductionUsed: Math.round(deductionUsed),
    taxableIncome: Math.round(taxableIncome),
    incomeTax: Math.round(incomeTax),
    selfEmploymentTax: Math.round(selfEmploymentTax),
    childTaxCredit: Math.round(childTaxCredit),
    otherDependentCredit: Math.round(otherDependentCredit),
    otherCredits: Math.round(otherCredits),
    estimatedFederalTax: Math.round(estimatedFederalTax),
    paymentsAndWithholding: Math.round(paymentsAndWithholding),
    balance: Math.round(balance),
    estimatedAmount: Math.round(estimatedAmount),
    result,
    effectiveRate:
      adjustedGrossIncome > 0
        ? Math.round((estimatedFederalTax / adjustedGrossIncome) * 10_000) / 100
        : 0,
  };
}