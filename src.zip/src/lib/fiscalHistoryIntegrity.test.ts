import assert from "node:assert/strict";
import test from "node:test";
import { summarizeFiscalHistoryIntegrity } from "./fiscalHistoryIntegrity.ts";

test("separates invalid fiscal amounts from invalid dates", () => {
  const summary = summarizeFiscalHistoryIntegrity([
    { estimatedAmount: "1250.50", createdAt: "2026-09-15T12:00:00.000Z" },
    { estimatedAmount: "not-a-number", createdAt: "2026-09-15T12:00:00.000Z" },
    { estimatedAmount: "900", createdAt: "not-a-date" },
    { estimatedAmount: "", createdAt: "also-not-a-date" },
  ]);

  assert.deepEqual(summary, {
    invalidRecordCount: 3,
    invalidAmountCount: 2,
    invalidDateCount: 2,
  });
});

test("treats non-string amounts and missing dates as invalid", () => {
  const summary = summarizeFiscalHistoryIntegrity([
    { estimatedAmount: 1250, createdAt: null },
  ]);

  assert.deepEqual(summary, {
    invalidRecordCount: 1,
    invalidAmountCount: 1,
    invalidDateCount: 1,
  });
});