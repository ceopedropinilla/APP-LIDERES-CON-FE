export interface FiscalHistoryRecord {
  estimatedAmount: unknown;
  createdAt: unknown;
}

export interface FiscalHistoryIntegritySummary {
  invalidRecordCount: number;
  invalidAmountCount: number;
  invalidDateCount: number;
}

function hasInvalidAmount(value: unknown): boolean {
  return typeof value !== "string"
    || value.trim() === ""
    || !Number.isFinite(Number(value));
}

function hasInvalidDate(value: unknown): boolean {
  if (!(typeof value === "string" || value instanceof Date)) {
    return true;
  }

  return Number.isNaN(new Date(value).getTime());
}

export function summarizeFiscalHistoryIntegrity(
  records: FiscalHistoryRecord[],
): FiscalHistoryIntegritySummary {
  let invalidRecordCount = 0;
  let invalidAmountCount = 0;
  let invalidDateCount = 0;

  for (const record of records) {
    const invalidAmount = hasInvalidAmount(record.estimatedAmount);
    const invalidDate = hasInvalidDate(record.createdAt);

    if (invalidAmount) invalidAmountCount += 1;
    if (invalidDate) invalidDateCount += 1;
    if (invalidAmount || invalidDate) invalidRecordCount += 1;
  }

  return { invalidRecordCount, invalidAmountCount, invalidDateCount };
}