import { pool } from "@workspace/db";
import { logger } from "./logger";

export async function ensureDatabaseSchema(): Promise<void> {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS user_progress (
      clerk_user_id text PRIMARY KEY,
      progress jsonb NOT NULL,
      revision integer NOT NULL DEFAULT 1,
      client_updated_at timestamptz NOT NULL,
      updated_at timestamptz NOT NULL DEFAULT now()
    )
  `);
  await pool.query(`
    ALTER TABLE user_progress
    ADD COLUMN IF NOT EXISTS revision integer NOT NULL DEFAULT 1
  `);
  logger.info("Database schema ready");
}