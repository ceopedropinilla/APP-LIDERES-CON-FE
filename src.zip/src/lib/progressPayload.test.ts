import assert from "node:assert/strict";
import test from "node:test";
import {
  progressPayloadSchema,
} from "./progressPayload.ts";

const deviceAProgress = {
  dataVersion: 1,
  updatedAt: "2026-09-14T20:00:00.000Z",
  profile: { name: "Device A" },
  lastRoute: "rosary",
  activityState: { rosary: { stepIndex: 4 } },
  governanceProgress: { mission: true },
  fiscalHistory: [{ result: "equilibrado" }],
  rosary: { stats: { completed: 3, streak: 2 }, history: ["joyful"] },
};

test("preserves the complete progress payload from another device", () => {
  const parsed = progressPayloadSchema.parse(deviceAProgress);

  assert.deepEqual(parsed.profile, deviceAProgress.profile);
  assert.deepEqual(parsed.activityState, deviceAProgress.activityState);
  assert.deepEqual(parsed.governanceProgress, deviceAProgress.governanceProgress);
  assert.deepEqual(parsed.fiscalHistory, deviceAProgress.fiscalHistory);
  assert.deepEqual(parsed.rosary, deviceAProgress.rosary);
});

test("preserves timestamps as data without using device clocks for ordering", () => {
  const parsed = progressPayloadSchema.parse({
    ...deviceAProgress,
    updatedAt: "2099-01-01T00:00:00.000Z",
  });

  assert.equal(parsed.updatedAt.toISOString(), "2099-01-01T00:00:00.000Z");
});