import { z } from "zod";

export const progressPayloadSchema = z
  .object({
    dataVersion: z.number().min(1),
    updatedAt: z.coerce.date(),
  })
  .passthrough();

export type ProgressPayload = z.infer<typeof progressPayloadSchema>;