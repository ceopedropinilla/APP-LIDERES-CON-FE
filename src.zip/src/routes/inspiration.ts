import { Router, type IRouter } from "express";
import { requireAuth } from "../middlewares/requireAuth";

const inspirationRouter: IRouter = Router();

// Curated pool of daily inspirations for Catholic entrepreneurs
const INSPIRATIONS = [
  {
    verse: "Encomienda al Señor tus obras, y tus planes se cumplirán.",
    reference: "Proverbios 16:3",
    reflection: "Todo proyecto empresarial que nace de la oración y se entrega a Dios lleva en sí la semilla del éxito verdadero. No el éxito del mundo, sino el que construye el Reino.",
    category: "Proverbios",
    morningMessage: "Antes de abrir tu agenda, entrega tus decisiones al Señor y pide sabiduría para servir.",
    financialAdvice: "Separa primero lo necesario para cumplir tus responsabilidades, evita decisiones impulsivas y administra con honestidad lo que se te ha confiado.",
    eveningMessage: "Antes de descansar, agradece por lo recibido, revisa tus decisiones con humildad y deja mañana en manos de Dios.",
  },
  {
    verse: "El que trabaja con mano negligente se empobrece; mas la mano de los diligentes enriquece.",
    reference: "Proverbios 10:4",
    reflection: "La excelencia en el trabajo es una forma de gloria a Dios. El empresario católico entiende que la diligencia no es codicia, sino administración fiel de los talentos recibidos.",
    category: "Proverbios",
  },
  {
    verse: "Porque del Señor es la tierra y todo lo que hay en ella.",
    reference: "Salmo 24:1",
    reflection: "La mayordomía comienza con reconocer que no somos dueños, sino administradores. Tu empresa, tus recursos, tus empleados — todo está confiado a tu cuidado, no a tu posesión.",
    category: "Salmos",
  },
  {
    verse: "Bienaventurado el hombre que halla sabiduría, y que obtiene la inteligencia; porque su ganancia es mejor que la ganancia de la plata.",
    reference: "Proverbios 3:13-14",
    reflection: "La sabiduría divina supera cualquier estrategia de negocios. Buscar a Dios primero en cada decisión empresarial es la inversión más rentable que puedes hacer.",
    category: "Proverbios",
  },
  {
    verse: "Todo lo que hagáis, hacedlo de corazón, como para el Señor y no para los hombres.",
    reference: "Colosenses 3:23",
    reflection: "Cuando trabajamos para Dios, la calidad, la honestidad y el servicio se vuelven actos de culto. Tu empresa puede ser un apostolado si la vives con esta conciencia.",
    category: "San Pablo",
  },
  {
    verse: "El amor nunca deja de ser. Pero las profecías se acabarán, cesarán las lenguas, y la ciencia se acabará.",
    reference: "1 Corintios 13:8",
    reflection: "En los negocios, el amor — entendido como servicio genuino al cliente y justicia al empleado — es la única estrategia que perdura. Los modelos cambian; el amor a Dios y al prójimo permanece.",
    category: "San Pablo",
  },
  {
    verse: "La empresa no puede considerarse solamente como una 'sociedad de capitales'; es también una 'sociedad de personas'.",
    reference: "Centesimus Annus, n. 43 — Juan Pablo II",
    reflection: "El Papa Juan Pablo II nos recuerda que detrás de cada línea contable hay seres humanos con dignidad. La empresa católica pone el bien de las personas por encima de la maximización del lucro.",
    category: "Doctrina Social",
  },
  {
    verse: "El Señor es mi pastor; nada me faltará.",
    reference: "Salmo 23:1",
    reflection: "La confianza en la Providencia no es ingenuidad empresarial — es la certeza de que Dios cuida de quien le sirve fielmente. Planifica con cuidado, pero descansa en Su guía.",
    category: "Salmos",
  },
  {
    verse: "Mas buscad primeramente el reino de Dios y su justicia, y todas estas cosas os serán añadidas.",
    reference: "Mateo 6:33",
    reflection: "Cuando el beneficio espiritual — la santidad, la justicia, el bien común — es la prioridad real de un empresario, los frutos materiales vienen como consecuencia, no como fin.",
    category: "Evangelio",
  },
  {
    verse: "El trabajo es un bien del hombre — es un bien de su humanidad — porque mediante el trabajo el hombre no sólo transforma la naturaleza, sino que también se realiza a sí mismo como hombre.",
    reference: "Laborem Exercens, n. 9 — Juan Pablo II",
    reflection: "El trabajo empresarial bien hecho es un camino de santificación. Cada decisión justa, cada empleado bien tratado, cada producto honesto es una ofrenda al Creador.",
    category: "Doctrina Social",
  },
  {
    verse: "Porque a todo el que tiene, se le dará y tendrá más; pero al que no tiene, aun lo que tiene se le quitará.",
    reference: "Mateo 25:29",
    reflection: "La parábola de los talentos es el fundamento de la mayordomía cristiana: Dios espera que multipliquemos con fidelidad y valentía lo que se nos ha confiado, sin enterrarlo por miedo.",
    category: "Evangelio",
  },
  {
    verse: "El sabio teme y se aparta del mal; mas el insensato se muestra insolente y confiado.",
    reference: "Proverbios 14:16",
    reflection: "La gestión del riesgo empresarial tiene raíces espirituales: la prudencia es una virtud cardinal. Alejarse del mal — del fraude, la explotación, la deshonestidad — es sabiduría, no debilidad.",
    category: "Proverbios",
  },
  {
    verse: "Confía en el Señor con todo tu corazón, y no te apoyes en tu propia prudencia.",
    reference: "Proverbios 3:5",
    reflection: "Las crisis empresariales son oportunidades de fe. Cuando los análisis fallan y los planes colapsan, el empresario de fe tiene un recurso que el mundo no ofrece: la oración y la confianza en el Padre.",
    category: "Proverbios",
  },
  {
    verse: "Si alguno de vosotros tiene falta de sabiduría, pídala a Dios, el cual da a todos abundantemente y sin reproche, y le será dada.",
    reference: "Santiago 1:5",
    reflection: "Antes de cada junta directiva, de cada decisión difícil, de cada contrato importante — pide sabiduría. Es una promesa de Dios, no solo un buen consejo.",
    category: "Santiago",
  },
  {
    verse: "Honra a Dios con tus bienes, y con las primicias de todos tus frutos.",
    reference: "Proverbios 3:9",
    reflection: "La diezma y la ofrenda generosa no son obligaciones pesadas sino actos de confianza radical en que Dios provee. El empresario que da el primer fruto a Dios afirma con sus finanzas lo que profesa con sus labios.",
    category: "Proverbios",
  },
];

inspirationRouter.get("/inspiration/daily", requireAuth, (_req, res) => {
  // Deterministic selection based on day of year
  const now = new Date();
  const dayOfYear = Math.floor(
    (now.getTime() - new Date(now.getFullYear(), 0, 0).getTime()) / 86400000
  );
  const index = dayOfYear % INSPIRATIONS.length;
  const inspiration = INSPIRATIONS[index];
  res.json({
    ...inspiration,
    morningMessage:
      "Antes de abrir tu agenda, entrega tus decisiones al Señor y pide sabiduría para servir.",
    financialAdvice:
      "Administra con honestidad lo que se te ha confiado, evita decisiones impulsivas y prioriza tus responsabilidades.",
    eveningMessage:
      "Antes de descansar, agradece por lo recibido, revisa tus decisiones con humildad y deja mañana en manos de Dios.",
  });
});

export default inspirationRouter;
