import { Router, type IRouter } from "express";
import healthRouter from "./health";
import chatRouter from "./chat";
import inspirationRouter from "./inspiration";
import fiscalRouter from "./fiscal";
import progressRouter from "./progress";

const router: IRouter = Router();

router.use(healthRouter);
router.use(chatRouter);
router.use(inspirationRouter);
router.use(fiscalRouter);
router.use(progressRouter);

export default router;
