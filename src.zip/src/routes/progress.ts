import { getAuth } from "@clerk/express";
import { db, userProgressTable } from "@workspace/db";
import {
  GetUserProgressResponse,
  SyncUserProgressBody,
  SyncUserProgressResponse,
} from "@workspace/api-zod";
import { eq, sql } from "drizzle-orm";
import { Router, type IRouter } from "express";
import { requireAuth } from "../middlewares/requireAuth";
import { progressPayloadSchema } from "../lib/progressPayload";

const progressRouter: IRouter = Router();

progressRouter.get("/progress", requireAuth, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Debes iniciar sesión para continuar." });
    return;
  }

  const [saved] = await db
    .select({
      progress: userProgressTable.progress,
      revision: userProgressTable.revision,
    })
    .from(userProgressTable)
    .where(eq(userProgressTable.clerkUserId, userId))
    .limit(1);

  const response = GetUserProgressResponse.safeParse({
    progress: saved?.progress ?? null,
    revision: saved?.revision ?? 0,
    accepted: true,
  });
  if (!response.success) {
    req.log.warn("Ignoring incomplete stored progress");
    res.json(GetUserProgressResponse.parse({
      progress: null,
      revision: saved?.revision ?? 0,
      accepted: true,
    }));
    return;
  }

  res.json(response.data);
});

progressRouter.put("/progress", requireAuth, async (req, res): Promise<void> => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Debes iniciar sesión para continuar." });
    return;
  }

  const parsed = SyncUserProgressBody.safeParse(req.body);
  if (!parsed.success) {
    req.log.warn({ errors: parsed.error.message }, "Invalid progress payload");
    res.status(400).json({ error: parsed.error.message });
    return;
  }

  const progressParsed = progressPayloadSchema.safeParse(req.body.progress);
  if (!progressParsed.success) {
    req.log.warn({ errors: progressParsed.error.message }, "Invalid progress data");
    res.status(400).json({ error: progressParsed.error.message });
    return;
  }

  const incoming = progressParsed.data;
  const incomingUpdatedAt = incoming.updatedAt;
  const baseRevision = parsed.data.baseRevision;

  const [stored] = await db
    .insert(userProgressTable)
    .values({
      clerkUserId: userId,
      progress: incoming,
      revision: 1,
      clientUpdatedAt: incomingUpdatedAt,
    })
    .onConflictDoUpdate({
      target: userProgressTable.clerkUserId,
      set: {
        progress: incoming,
        revision: sql`${userProgressTable.revision} + 1`,
        clientUpdatedAt: incomingUpdatedAt,
        updatedAt: new Date(),
      },
      setWhere: sql`
        NOT (${userProgressTable.progress} ? 'lastRoute')
        OR ${userProgressTable.revision} = ${baseRevision ?? -1}
      `,
    })
    .returning({
      progress: userProgressTable.progress,
      revision: userProgressTable.revision,
    });

  if (stored) {
    res.json(SyncUserProgressResponse.parse({
      progress: stored.progress,
      revision: stored.revision,
      accepted: true,
    }));
    return;
  }

  const [latest] = await db
    .select({
      progress: userProgressTable.progress,
      revision: userProgressTable.revision,
    })
    .from(userProgressTable)
    .where(eq(userProgressTable.clerkUserId, userId))
    .limit(1);

  res.json(SyncUserProgressResponse.parse({
    progress: latest.progress,
    revision: latest.revision,
    accepted: false,
  }));
});

export default progressRouter;