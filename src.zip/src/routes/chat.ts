import { Router, type IRouter } from "express";
import { openai } from "@workspace/integrations-openai-ai-server";
import type OpenAI from "openai";
import { SendChatMessageBody } from "@workspace/api-zod";
import {
  catholicKnowledgeTable,
  db,
  type CatholicKnowledge,
} from "@workspace/db";
import { asc } from "drizzle-orm";
import { requireAuth } from "../middlewares/requireAuth";

const SYSTEM_PROMPT = `Eres un guía espiritual y consejero de negocios para empresarios católicos.
Tu misión es responder preguntas de negocios con sabiduría arraigada en:
- La Sagrada Biblia (especialmente Proverbios, Salmos, Evangelios, Cartas de Pablo)
- La Doctrina Social de la Iglesia (Centesimus Annus, Rerum Novarum, Laudato Si, Laudato Deum)
- La guía del Espíritu Santo y la sabiduría de los Santos
- La ética católica en los negocios: justicia, bien común, dignidad humana, mayordomía

Formato de tus respuestas:
1. Una reflexión espiritual y práctica de 2-4 párrafos respondiendo la pregunta
2. Incluye 2-3 referencias bíblicas o documentos de la Iglesia específicos
3. Cierra con una oración corta (2-3 líneas) relacionada al tema

Tono: cálido, paternal, sabio — como un sacerdote o mentor espiritual que también conoce el mundo empresarial.
Responde siempre en español. No uses emojis. Sé directo, práctico y profundamente espiritual.

Reglas importantes sobre tus fuentes:
- Usa el CONTEXTO CATÓLICO proporcionado debajo como tu fuente principal y cítalo con su referencia exacta.
- No inventes citas textuales, números de párrafo, encíclicas ni referencias bíblicas.
- Si el contexto no contiene una respuesta suficiente, dilo con honestidad y ofrece una orientación pastoral prudente sin presentarla como una cita.
- La Biblia usada por la aplicación es la Biblia Católica; diferencia claramente entre una cita bíblica y una enseñanza de una encíclica.`;

const chatRouter: IRouter = Router();

function normalizeMessage(value: string) {
  return value
    .toLocaleLowerCase("es")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[¡!¿?,.;:]+/g, " ")
    .replace(/\s+/g, " ")
    .trim();
}

function isGreeting(value: string) {
  const normalized = normalizeMessage(value);
  return /^(hola|holaa+|buenos dias|buenas tardes|buenas noches|buen dia|buenas|saludos|que tal|como estas)$/.test(
    normalized,
  );
}

const BUILTIN_KNOWLEDGE: CatholicKnowledge[] = [
  {
    id: -1,
    sourceType: "Biblia Católica",
    title: "Dignidad del trabajador",
    reference: "Deuteronomio 24:14-15",
    content:
      "No explotarás al jornalero pobre y necesitado; le darás su salario el mismo día, antes de que se ponga el sol.",
    keywords: "salarios empleados trabajo justicia dignidad pago explotación despido",
    createdAt: new Date(0),
  },
  {
    id: -2,
    sourceType: "Encíclica / Doctrina Social",
    title: "La empresa como sociedad de personas",
    reference: "Centesimus Annus, n. 43",
    content:
      "La empresa no puede considerarse únicamente como una sociedad de capitales; es también una sociedad de personas, en la que participan de diversos modos y con responsabilidades específicas quienes aportan el capital y quienes colaboran con su trabajo.",
    keywords:
      "empresa personas capital trabajadores dignidad liderazgo empleados personal",
    createdAt: new Date(0),
  },
  {
    id: -3,
    sourceType: "Encíclica / Doctrina Social",
    title: "El salario justo",
    reference: "Rerum Novarum, n. 34",
    content:
      "El trabajo no es una mercancía; la dignidad de la persona exige que el salario permita al trabajador sostener dignamente a su familia y que la justicia presida las relaciones laborales.",
    keywords:
      "salario justo trabajo empleados familia justicia compensación personal",
    createdAt: new Date(0),
  },
  {
    id: -4,
    sourceType: "Biblia Católica",
    title: "Justicia en las transacciones",
    reference: "Proverbios 11:1",
    content:
      "El Señor aborrece las balanzas falsas, pero la pesa exacta le agrada.",
    keywords: "justicia transparencia precios ventas fraude contabilidad ingresos",
    createdAt: new Date(0),
  },
  {
    id: -5,
    sourceType: "Encíclica / Doctrina Social",
    title: "La empresa y el bien común",
    reference: "Centesimus Annus, n. 35",
    content:
      "La empresa tiene como finalidad no solamente la producción de beneficios, sino también la existencia misma de la empresa como comunidad de personas, que busca satisfacer sus necesidades fundamentales y constituye un grupo particular al servicio de la sociedad entera.",
    keywords:
      "empresa beneficios comunidad bien comun sociedad propósito crisis ventas",
    createdAt: new Date(0),
  },
];

const TOPIC_SYNONYMS: Record<string, string[]> = {
  ventas: ["ventas", "ingresos", "clientes", "facturacion", "comercial"],
  bajas: ["crisis", "caida", "perdidas", "dificultad", "bajo"],
  despido: ["despido", "despedir", "recorte", "reduccion", "empleados", "personal"],
  personal: ["personal", "empleados", "trabajadores", "equipo", "colaboradores"],
  salario: ["salario", "sueldo", "compensacion", "pago", "remuneracion"],
  trabajo: ["trabajo", "empleo", "laboral", "empleados", "trabajadores"],
  justicia: ["justicia", "dignidad", "bien", "comun", "solidaridad"],
};

type AppSection = "daily" | "library" | "stewardship" | "governance" | "fiscal";

interface ChatNavigation {
  section: AppSection;
  label: string;
  reason: string;
}

function detectNavigation(message: string, response = ""): ChatNavigation | undefined {
  const normalizedMessage = normalizeMessage(message);
  const normalizedResponse = normalizeMessage(response);
  const messageMatches = (pattern: RegExp) => pattern.test(normalizedMessage);
  const responseMatches = (pattern: RegExp) => pattern.test(normalizedResponse);

  if (messageMatches(
    /(impuesto|impuestos|tax|tribut|irs|declar|reembolso|refund|itin|social security|seguro social|dependiente|w2|w-2|1099|schedule c|s corporation|c corporation|llc|pago estimado|trimestral)/,
  )) {
    return {
      section: "fiscal",
      label: "Abrir Diagnóstico Fiscal",
      reason: "Tu pregunta menciona impuestos, dependientes, declaraciones o pagos estimados.",
    };
  }

  if (messageMatches(
    /(presupuesto|flujo de caja|flujo de efectivo|dinero|deuda|ahorro|gasto|ingreso|ventas|precio|ganancia|rentabilidad|mayordomia|mayordomía|administrar finanzas|finanzas del negocio)/,
  )) {
    return {
      section: "stewardship",
      label: "Abrir Mayordomía",
      reason: "Esta consulta se relaciona con administrar recursos, dinero o decisiones financieras.",
    };
  }

  if (messageMatches(
    /(gobernanza|gobierno corporativo|politica|política|regla|cumplimiento|riesgo|contrato|socio|junta|liderazgo|estructura|organizacion|organización|mision de la empresa|misión de la empresa|valores de la empresa)/,
  )) {
    return {
      section: "governance",
      label: "Abrir Gobernanza",
      reason: "La situación parece requerir ordenar responsabilidades, valores, riesgos o decisiones de liderazgo.",
    };
  }

  if (messageMatches(
    /(orar|orando|reza|rezar|oracion|oración|reflexion|reflexión|inspiracion|inspiración|meditacion|meditación|hoy|mañana|manana|noche|paz|discernir|discernimiento)/,
  )) {
    return {
      section: "daily",
      label: "Abrir Inspiración Diaria",
      reason: "Tu consulta parece pedir un momento de oración, reflexión o discernimiento diario.",
    };
  }

  if (messageMatches(
    /(biblia|versiculo|versículo|evangelio|enciclica|encíclica|vaticano|doctrina social|iglesia|documento catolico|documento católico|santo|santa|cita|pasaje)/,
  )) {
    return {
      section: "library",
      label: "Abrir Biblioteca Católica",
      reason: "Parece que estás buscando una fuente bíblica, doctrinal o un documento de la Iglesia.",
    };
  }

  // Only infer from the generated answer when the user's wording was
  // ambiguous. This prevents references such as "cita", "liderazgo", or
  // "oración" in an answer from overriding the user's actual intent.
  const responseMatchesAny = (pattern: RegExp) => responseMatches(pattern);

  if (responseMatchesAny(
    /(impuesto|impuestos|tax|tribut|irs|declar|reembolso|refund|itin|social security|seguro social|dependiente|w2|w-2|1099|schedule c|s corporation|c corporation|llc|pago estimado|trimestral)/,
  )) {
    return {
      section: "fiscal",
      label: "Abrir Diagnóstico Fiscal",
      reason: "La respuesta se relaciona con impuestos, dependientes, declaraciones o pagos estimados.",
    };
  }

  if (responseMatchesAny(
    /(presupuesto|flujo de caja|flujo de efectivo|dinero|deuda|ahorro|gasto|ingreso|ventas|precio|ganancia|rentabilidad|mayordomia|mayordomía|administrar finanzas|finanzas del negocio)/,
  )) {
    return {
      section: "stewardship",
      label: "Abrir Mayordomía",
      reason: "La respuesta se relaciona con administrar recursos, dinero o decisiones financieras.",
    };
  }

  if (responseMatchesAny(
    /(gobernanza|gobierno corporativo|politica|política|regla|cumplimiento|riesgo|contrato|socio|junta|liderazgo|estructura|organizacion|organización|mision de la empresa|misión de la empresa|valores de la empresa)/,
  )) {
    return {
      section: "governance",
      label: "Abrir Gobernanza",
      reason: "La respuesta se relaciona con ordenar responsabilidades, valores, riesgos o decisiones de liderazgo.",
    };
  }

  if (responseMatchesAny(
    /(orar|orando|reza|rezar|oracion|oración|reflexion|reflexión|inspiracion|inspiración|meditacion|meditación|hoy|mañana|manana|noche|paz|discernir|discernimiento)/,
  )) {
    return {
      section: "daily",
      label: "Abrir Inspiración Diaria",
      reason: "La respuesta invita a un momento de oración, reflexión o discernimiento diario.",
    };
  }

  if (responseMatchesAny(
    /(biblia|versiculo|versículo|evangelio|enciclica|encíclica|vaticano|doctrina social|iglesia|documento catolico|documento católico|santo|santa|cita|pasaje)/,
  )) {
    return {
      section: "library",
      label: "Abrir Biblioteca Católica",
      reason: "La respuesta incluye una fuente bíblica, doctrinal o un documento de la Iglesia.",
    };
  }

  return undefined;
}

function expandQueryTerms(message: string) {
  const normalized = normalizeMessage(message);
  const terms = normalized
    .split(/\W+/)
    .filter((term) => term.length >= 4);
  const expanded = new Set(terms);

  for (const term of terms) {
    for (const synonym of TOPIC_SYNONYMS[term] ?? []) {
      expanded.add(synonym);
    }
  }

  if (/(venta|ingreso|factur|cliente|comercial)/.test(normalized)) {
    TOPIC_SYNONYMS.ventas.forEach((term) => expanded.add(term));
  }
  if (/(baj|caida|perdid|crisis|no alcanza)/.test(normalized)) {
    TOPIC_SYNONYMS.bajas.forEach((term) => expanded.add(term));
  }
  if (/(despid|recort|personal|emplead|trabajador)/.test(normalized)) {
    TOPIC_SYNONYMS.despido.forEach((term) => expanded.add(term));
    TOPIC_SYNONYMS.trabajo.forEach((term) => expanded.add(term));
  }

  return [...expanded];
}

function isEmploymentCrisis(message: string) {
  const normalized = normalizeMessage(message);
  return (
    /(venta|ingreso|factur|cliente|comercial|baj|caida|perdid|crisis)/.test(
      normalized,
    ) &&
    /(despid|recort|emplead|personal|trabajador|equipo)/.test(normalized)
  );
}

chatRouter.post("/chat", requireAuth, async (req, res) => {
  const parsed = SendChatMessageBody.safeParse(req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Solicitud inválida" });
    return;
  }

  const { message, history } = parsed.data;

  // Greetings are handled by the app itself. They should not trigger
  // Scripture retrieval or an AI response with an unrelated citation.
  if (isGreeting(message)) {
    res.json({
      message:
        "Hola. Qué gusto acompañarte hoy. ¿Qué inquietud, decisión o desafío de tu empresa quieres conversar?",
      references: [],
      prayer: "",
      navigation: undefined,
    });
    return;
  }

  let relevantKnowledge: CatholicKnowledge[] = [];

  try {
    const storedKnowledge = await db
      .select()
      .from(catholicKnowledgeTable)
      .orderBy(asc(catholicKnowledgeTable.id));
    const knowledge = Array.from(
      new Map(
        [...BUILTIN_KNOWLEDGE, ...storedKnowledge].map((entry) => [
          entry.reference,
          entry,
        ]),
      ).values(),
    );

    const queryTerms = expandQueryTerms(message);

    relevantKnowledge = knowledge
      .map((entry) => {
        const searchable = `${entry.title} ${entry.reference} ${entry.content} ${entry.keywords}`
          .toLocaleLowerCase("es")
          .normalize("NFD")
          .replace(/[\u0300-\u036f]/g, "");
        const score = queryTerms.reduce(
          (total, term) => total + (searchable.includes(term) ? 1 : 0),
          0,
        );
        return { entry, score };
      })
      .filter(({ score }) => score > 0)
      .sort((a, b) => b.score - a.score)
      .slice(0, 8)
      .map(({ entry }) => entry);

    const catholicContext =
      relevantKnowledge.length > 0
        ? relevantKnowledge
            .map(
              (entry) =>
                `[${entry.sourceType}] ${entry.title} — ${entry.reference}\n${entry.content}`,
            )
            .join("\n\n")
        : "No se encontró un pasaje específico en la base de conocimiento.";

    const messages: OpenAI.Chat.ChatCompletionMessageParam[] = [
      {
        role: "system",
        content: `${SYSTEM_PROMPT}\n\nCONTEXTO CATÓLICO DE LA BASE DE DATOS:\n${catholicContext}`,
      },
      ...history.map((h) => ({
        role: h.role as "user" | "assistant",
        content: h.content,
      })),
      { role: "user", content: message },
    ];

    const completion = await openai.chat.completions.create({
      model: "gpt-5.4-mini",
      max_completion_tokens: 1024,
      messages,
    });

    const rawContent = completion.choices[0]?.message?.content ?? "";

    // Extract prayer (last paragraph starting with "Señor" or similar)
    const paragraphs = rawContent.trim().split(/\n\n+/);
    const lastParagraph = paragraphs[paragraphs.length - 1] ?? "";
    const prayerKeywords = ["señor", "padre", "dios", "espíritu", "amén", "amen", "te pedimos", "oramos"];
    const hasPrayer = prayerKeywords.some((kw) =>
      lastParagraph.toLowerCase().startsWith(kw) || lastParagraph.toLowerCase().includes(kw)
    );

    const prayer = hasPrayer ? lastParagraph : "Señor, ilumina nuestros caminos empresariales con Tu sabiduría. Amén.";
    const mainMessage = hasPrayer
      ? paragraphs.slice(0, -1).join("\n\n")
      : rawContent;

    // Extract bible references from the text
    const refPattern = /(?:\d\s)?[A-ZÁÉÍÓÚÜÑ][a-záéíóúüñ]+(?:\s+\d+)?:\d+(?:-\d+)?/g;
    const docPattern = /(?:Centesimus Annus|Rerum Novarum|Laudato Si|Laudato Deum|Gaudium et Spes|Caritas in Veritate|Populorum Progressio)(?:\s+n\.?\s*\d+)?/g;
    const refsFromResponse = [
      ...(rawContent.match(refPattern) ?? []),
      ...(rawContent.match(docPattern) ?? []),
    ].slice(0, 5);
    const refsFromDatabase = relevantKnowledge
      .map((entry) => entry.reference)
      .filter((reference) => rawContent.includes(reference));
    const refs = [...new Set([...refsFromDatabase, ...refsFromResponse])].slice(
      0,
      5,
    );

    res.json({
      message: mainMessage,
      references: refs.length > 0 ? refs : ["Proverbios 16:3", "Mateo 25:14-30"],
      prayer,
      navigation: detectNavigation(message, mainMessage),
    });
  } catch (err) {
    req.log.error({ err }, "OpenAI chat error");
    const errorStatus =
      typeof err === "object" && err !== null && "status" in err
        ? (err as { status?: number }).status
        : undefined;

    // Keep the spiritual chat useful when the external model is unavailable.
    // The response is assembled only from the Catholic knowledge base above,
    // so it never presents an invented citation as Church teaching.
    if (errorStatus === 401 || errorStatus === 403) {
      const storedFallbackKnowledge =
        await db
          .select()
          .from(catholicKnowledgeTable)
          .orderBy(asc(catholicKnowledgeTable.id))
          .limit(3);
      const fallbackKnowledge =
        relevantKnowledge.length > 0
          ? relevantKnowledge.slice(0, 3)
          : storedFallbackKnowledge.length > 0
            ? storedFallbackKnowledge
            : BUILTIN_KNOWLEDGE;

      const leadEntry = fallbackKnowledge[0];
      const fallbackMessage = isEmploymentCrisis(message)
        ? `Cuando las ventas bajan, no tomes una decisión sobre tu personal únicamente desde el miedo. Primero revisa con prudencia el flujo de caja, separa lo urgente de lo prescindible, busca consejo con tu equipo y considera alternativas temporales —reducción de gastos no esenciales, reorganización o acuerdos transparentes— antes de llegar a un despido. Si la continuidad de la empresa exige reducir puestos, hazlo como último recurso, con respeto, justicia, comunicación clara y cumpliendo la ley; nunca trates a las personas como una cifra.\n\nLa Doctrina Social recuerda que la empresa es una sociedad de personas y que el trabajo conserva la dignidad de quien lo realiza.`
        : leadEntry
          ? `**${leadEntry.title}**\n\n“${leadEntry.content}”\n\nPara tu pregunta, este principio invita a actuar con justicia, prudencia y servicio al bien común. Discierne tu siguiente paso con oración y busca consejo pastoral cuando la decisión tenga consecuencias importantes.`
        : "La base de conocimiento católica está disponible, pero no se encontró un pasaje relacionado con esta pregunta.";

      res.json({
        message: fallbackMessage,
        references: fallbackKnowledge.map((entry) => entry.reference),
        prayer:
          "Señor, ilumina nuestro discernimiento y ayúdanos a servir con justicia. Amén.",
        navigation: detectNavigation(message, fallbackMessage),
      });
      return;
    }

    res.status(500).json({
      error: "Error al procesar tu consulta espiritual. Intenta de nuevo.",
    });
  }
});

export default chatRouter;
