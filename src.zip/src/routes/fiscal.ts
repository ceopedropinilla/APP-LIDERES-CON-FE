import { Router, type IRouter } from "express";
import { clerkClient, getAuth } from "@clerk/express";
import { db, fiscalDiagnosticsTable } from "@workspace/db";
import { desc, eq } from "drizzle-orm";
import { requireAuth } from "../middlewares/requireAuth";
import { requireAdmin } from "../middlewares/requireAdmin";
import {
  calculateFiscalSimulation,
  fiscalInputSchema,
} from "../lib/fiscalCalculator";
import { summarizeFiscalHistoryIntegrity } from "../lib/fiscalHistoryIntegrity";
import { z } from "zod";

const fiscalRouter: IRouter = Router();

const leadCaptureSchema = z.object({
  phone: z.string().trim().min(7, "Escribe un teléfono válido.").max(30),
  contactPreference: z.enum(["phone", "whatsapp", "email"]),
  consent: z.literal(true),
});

// POST /api/fiscal/simulate — calculate without saving (authenticated users)
fiscalRouter.post("/fiscal/simulate", requireAuth, (req, res) => {
  const parsed = fiscalInputSchema.safeParse(req.body?.inputs ?? req.body);
  if (!parsed.success) {
    res.status(400).json({ error: "Revisa los datos de la simulación.", details: parsed.error.flatten() });
    return;
  }

  res.json(calculateFiscalSimulation(parsed.data));
});

// GET /api/fiscal/mine — current user's saved simulations
fiscalRouter.get("/fiscal/mine", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Debes iniciar sesión." });
    return;
  }

  try {
    const rows = await db
      .select()
      .from(fiscalDiagnosticsTable)
      .where(eq(fiscalDiagnosticsTable.clerkUserId, userId))
      .orderBy(desc(fiscalDiagnosticsTable.createdAt));

    const integrity = summarizeFiscalHistoryIntegrity(rows);
    if (integrity.invalidRecordCount > 0) {
      req.log.warn(
        {
          event: "fiscal_history_invalid_records",
          invalidRecordCount: integrity.invalidRecordCount,
          invalidAmountCount: integrity.invalidAmountCount,
          invalidDateCount: integrity.invalidDateCount,
        },
        "Invalid fiscal history records rejected by client",
      );
    }

    res.json(rows);
  } catch (err) {
    req.log.error({ err }, "Error fetching user's fiscal simulations");
    res.status(500).json({ error: "Error al obtener tus simulaciones." });
  }
});

// POST /api/fiscal/lead — save a simulation and request tax-service follow-up
fiscalRouter.post("/fiscal/lead", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Debes iniciar sesión." });
    return;
  }

  const parsedInputs = fiscalInputSchema.safeParse(req.body?.inputs);
  const parsedLead = leadCaptureSchema.safeParse(req.body?.lead);

  if (!parsedInputs.success || !parsedLead.success) {
    res.status(400).json({
      error: "Revisa los datos de contacto y acepta el permiso de seguimiento.",
      details: {
        inputs: parsedInputs.success ? undefined : parsedInputs.error.flatten(),
        lead: parsedLead.success ? undefined : parsedLead.error.flatten(),
      },
    });
    return;
  }

  try {
    const user = await clerkClient.users.getUser(userId);
    const calculation = calculateFiscalSimulation(parsedInputs.data);
    const [saved] = await db
      .insert(fiscalDiagnosticsTable)
      .values({
        clerkUserId: userId,
        email: user.primaryEmailAddress?.emailAddress ?? "",
        name: [user.firstName, user.lastName].filter(Boolean).join(" "),
        answers: parsedInputs.data,
        result: calculation.result,
        estimatedAmount: String(calculation.estimatedAmount),
        contactPhone: parsedLead.data.phone,
        contactPreference: parsedLead.data.contactPreference,
        contactConsent: true,
        leadStatus: "nuevo",
      })
      .returning();

    res.json({ diagnostic: saved, calculation });
  } catch (err) {
    req.log.error({ err }, "Error saving fiscal lead");
    res.status(500).json({ error: "No se pudo enviar tu solicitud. Inténtalo de nuevo." });
  }
});

// POST /api/fiscal — calculate and save a completed simulation
fiscalRouter.post("/fiscal", requireAuth, async (req, res) => {
  const { userId } = getAuth(req);
  if (!userId) {
    res.status(401).json({ error: "Debes iniciar sesión." });
    return;
  }

  const { email, name, answers, result, estimatedAmount } = req.body;
  const parsedInputs = fiscalInputSchema.safeParse(req.body?.inputs ?? answers);

  if (!parsedInputs.success) {
    res.status(400).json({ error: "Faltan o son inválidos los datos de la simulación." });
    return;
  }

  try {
    const calculation = calculateFiscalSimulation(parsedInputs.data);
    const [saved] = await db
      .insert(fiscalDiagnosticsTable)
      .values({
        clerkUserId: userId,
        email: email ?? "",
        name: name ?? "",
        answers: parsedInputs.data,
        result: calculation.result,
        estimatedAmount: String(calculation.estimatedAmount),
      })
      .returning();

    res.json({ diagnostic: saved, calculation });
  } catch (err) {
    req.log.error({ err }, "Error saving fiscal diagnostic");
    res.status(500).json({ error: "Error al guardar el diagnóstico." });
  }
});

// GET /api/fiscal/admin — list all diagnostics (admin only)
fiscalRouter.get("/fiscal/admin", requireAuth, requireAdmin, async (req, res) => {
  try {
    const rows = await db
      .select()
      .from(fiscalDiagnosticsTable)
      .orderBy(desc(fiscalDiagnosticsTable.createdAt));

    res.json(rows);
  } catch (err) {
    req.log.error({ err }, "Error fetching fiscal diagnostics");
    res.status(500).json({ error: "Error al obtener los diagnósticos." });
  }
});

export default fiscalRouter;
